
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl
#include <cstdlib>
#include <ctime>
using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Seed random number generator once, here only
    srand (static_cast<unsigned int>(time(0)));
    
    
    //Declare Variables
    unsigned char f1=32,f2=212,c1=0,c2=100; //Table values for Temperature
    float m=5.0f/9.0f, b=32.0f; //Polynomial coefficients
    float ceq,cint,f;  //Temperature values and conversions
    
    //Initial Variables
    f=rand()%181+32;//[32,212]
    
            
    //Map/Process Inputs to Outputs
    ceq=m*(f+b);
    cint=c1+static_cast<float>(c2-c1)/(f2-f1)*(f-f1);
    
    //Display Outputs
    cout<<f<<" Fahrenheit = "
            <<ceq<<" Centigrade equation "
            <<cint<<" Celsius interpolation"<<endl;
    //Exit Program
    return 0;
}

