
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float test1,
          test2,
          test3,
          test4,
          test5,
          totScor;
    
    //Initialize Variables
    
    //Map/Process Inputs to output
    cout<<"This program calculates your test score average."<<endl;
    cout<<"Input your first test score in 00 format : "<<endl;
    cin>>test1;
    cout<<"Input your second test score in 00 format : "<<endl;
    cin>>test2;
    cout<<"Input your third test score in 00 format : "<<endl;
    cin>>test3;
    cout<<"Input your fourth test score in 00 format : "<<endl;
    cin>>test4;
    cout<<"Input your fifth test score in 00 format : "<<endl;
    cin>>test5;
    
    totScor=(test1+test2+test3+test4+test5)/5;
    //Display Your Outputs
    cout<<"Your Average test score is : "<<totScor<<endl;
    
    //Exit Program
    return 0;
}

