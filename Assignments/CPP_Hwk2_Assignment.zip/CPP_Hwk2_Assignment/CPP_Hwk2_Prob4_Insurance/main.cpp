
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created
const char PERCENT = 100;
//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float propCst,
          insur,  
          insRplc;
    
    //Initialize Variables
    insur=80;
    //Map/Process Inputs to output
    cout<<"This program calculates how much insurance should be purchased "
        <<"for your property."<<endl;
    cout<<"Input the cost for your property in $'s : $"<<endl;
    cin>>propCst;
    
    insRplc= propCst*(insur/PERCENT);
    
    //Display Your Outputs
    cout<<"The total amount of insurance you should purchase is : $"
        <<insRplc<<endl;
    
    //Exit Program
    return 0;
}

