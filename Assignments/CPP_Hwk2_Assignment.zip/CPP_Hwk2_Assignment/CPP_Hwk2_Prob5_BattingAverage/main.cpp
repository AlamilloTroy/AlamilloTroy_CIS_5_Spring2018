
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl
#include <iomanip>
using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float   bats,   //Number of times went to bat
            hits,   //Number of times hit
            total;  //Total batting average
    
    //Initialize Variables
    
    //Map/Process Inputs to output
     cout<<"How many times did you go to bat?"<<endl;
    cin>>bats;
    
    cout<<"How man times did you hit?"<<endl;
    cin>>hits;
    
    //Math
    total = hits/bats;
    
    //Display Your Outputs
     cout<<"The total batting average is: "<<setprecision(5)<<total<<endl;
     
    //Exit Program
    return 0;
}

