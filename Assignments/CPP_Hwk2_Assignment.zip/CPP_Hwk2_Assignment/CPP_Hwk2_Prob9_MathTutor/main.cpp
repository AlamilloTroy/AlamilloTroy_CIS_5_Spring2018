
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <cstdlib>  //Random number library
#include <ctime>    //Time to set random number seed
#include <iomanip>
using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    unsigned short op1,op2,stuAns,correct;
    //Initial Variables
    op1=rand()%900+100; //[100,999]
    op2=rand()%999+1;   //[1,999]
    cout<<"This is a simple Math Tutor Program"<<endl;
    cout<<"Input the Answer to the following addition problem"<<endl;
    cout<<setw(5)<<op1<<endl;
    cout<<"+ "<<setw(3)<<op2<<endl;
    cout<<"------"<<endl;
    cin>>stuAns;
    //Map/Process Inputs to Outputs
    correct=op1+op2;
    //Display Outputs
    cout<<endl<<(stuAns==correct?"Correct Answer":"Try Again Next Time!")<<endl;
    //Exit Program
    return 0;
}

