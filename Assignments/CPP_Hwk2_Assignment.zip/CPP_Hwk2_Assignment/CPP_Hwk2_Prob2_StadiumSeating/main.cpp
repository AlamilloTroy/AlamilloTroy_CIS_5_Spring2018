
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float   classAp,    //Class A seating price
            classA,     //Class A seats
            classBp,    //Class B seating price
            classB,     //Class B seats
            classCp,    //Class C seating price
            classC,     //Class C seats
            totseat,    //amount of seating
            totprc;     //amount paid
    
    //Initialize Variables
    classAp = 15;  
    classBp = 12;  
    classCp = 9;   
    
    //Map/Process Inputs to output
     cout<<"How many Class A seats would you like to order?"<<endl;
    cin>>classA;
    cout<<"How many Class B seats would you like to order?"<<endl;
    cin>>classB;
    cout<<"How many Class C seats would you like to order?"<<endl;
    cin>>classC;
    
    //Math
     totprc = (classA*classAp)+(classBp*classB)+(classCp*classC);
    totseat = classA+classB+classC;
    
    //Display Your Outputs
    cout<<"Class A seats: "<<classA<<"."<<endl;
    cout<<"Class B seats: "<<classB<<"."<<endl;
    cout<<"Class C seats: "<<classC<<"."<<endl;
    cout<<"Total Seating: "<<totseat<<"."<<endl;
    cout<<"Total Price:   "<<totprc<<" $"<<endl;
    
    //Exit Program
    return 0;
}

