
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: Gaddis 9th Edition Homework Assignment 2 Problem 3
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column
const float YEAR = 12;    //12 Months in a year
const float MONTH = 30;    //30 Days in a month

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float   rent,       //Amount paid for rent
            mrgpymt,    //Mortgage payment
            phone,      //Phone bill
            cable,      //Cable bill
            util,       //Utilities paid
            yeartot,    //Total amount paid Annually
            total;      //Total amount paid monthly
    
    //Initialize Variables
    
    //Map/Process Inputs to output
     cout<<"What is your monthly bill for your rent?"<<endl;
    cin>>rent;
    cout<<"What is your monthly mortgage payment?"<<endl;
    cin>>mrgpymt;
    cout<<"What is your monthly phone bill?"<<endl;
    cin>>phone;
    cout<<"How much do you pay monthly for your cable?"<<endl;
    cin>>cable;
    cout<<"How much do you pay monthly for your utilities?"<<endl;
    cin>>util;
    
    //Math
    total = rent+mrgpymt+phone+cable+util;
    yeartot = total*YEAR;
    
    //Display Your Outputs
    cout<<"Rent: $"<<rent<<endl;
    cout<<"Mortgage Payment: $"<<mrgpymt<<endl;
    cout<<"Phone Bill: $"<<phone<<endl;
    cout<<"Utilities: $"<<util<<endl;
    cout<<"Total Monthly: $"<<total<<endl;
    cout<<"Annual Total: $"<<yeartot<<endl;
    
    //Exit Program
    return 0;
}

