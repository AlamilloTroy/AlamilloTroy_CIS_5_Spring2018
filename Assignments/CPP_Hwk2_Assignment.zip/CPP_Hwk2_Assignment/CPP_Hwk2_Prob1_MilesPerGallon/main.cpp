/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 * Created on March 12
 * Purpose:  Gaddis 9th Ed Homework Assignment 2 Problem 1
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float   gallon,
            miles,
            mpg;
    
    //Input or initialize values Here
    cout<<"This program calculates the total miles your car gets to the gallon"
            <<endl;
    cout<<"Input how many gallons of gas your tank holds as well as how many"
           <<" miles your car can drive with a full tank."<<endl;
    cin>>gallon;
    cin>>miles;
    
    //Process/Calculations Here
     mpg=miles/gallon;
     
    //Output Located Here
    cout<<"The car gets "<<mpg<<" miles to the gallon"<<endl;

    //Exit
    return 0;
}

