
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on February 28, 2018
 * Purpose: Homework Assignment 1 Problem 2 Gaddis 9th Edition
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2D Array Column
const char PERCENT=100; //Percentage 
const float MLLN=1.0e06f; //Million
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float ttlSale, //Sales total budget
          EaCopct, //Sales percentage generation of total sales
          ttlEaCo; //East Coast total generated
          
    //Initialize Variables
     ttlSale = 8.6*MLLN;
     EaCopct = 58;
    //Map/Process Inputs to output
     EaCopct = EaCopct/PERCENT;
     ttlEaCo = ttlSale*EaCopct;
    //Display Your Outputs
     cout<<"Input the Total Sales (in millions) and the percentage "
         <<"the East Coast Division will generate this year."<<endl;
     cin>> ttlSale;
     cin>> EaCopct;
     cout<<"Total East Coast Division Sales = $"<<ttlEaCo/MLLN
         <<"Million."<<endl;
    //Exit Program
    return 0;
}

