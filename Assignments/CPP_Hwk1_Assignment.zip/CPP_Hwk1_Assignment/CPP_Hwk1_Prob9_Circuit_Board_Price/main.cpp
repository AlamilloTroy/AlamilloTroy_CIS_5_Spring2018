
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: Homework Assignment 1 Problem 9 
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created
const char PERCENT = 100;
const float PROFIT = 35;
//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float crBoard,
          ttPrice,  
          pctProf;  
           
    //Initialize Variables
    crBoard = 14.95;
    
    
    //Map/Process Inputs to output
     pctProf = crBoard*(PROFIT/PERCENT);
     ttPrice = crBoard + pctProf;
    //Display Your Outputs
     cout<<"If the electronics company wants to make a profit,"
         <<" then they would have to sell the circuit board at a price of $"
         <<ttPrice<<"."<<endl;   
    //Exit Program
    return 0;
}

