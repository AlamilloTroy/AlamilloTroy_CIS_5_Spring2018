
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float mpgTown,
          mpgHigh,
          mileTwn,
          mileHgh,  
          gallon;  
    //Initialize Variables
    gallon = 20;
    mpgTown = 23.5;
    mpgHigh = 28.9;
    mileTwn = mpgTown*gallon;
    mileHgh = mpgHigh*gallon;        
    
    //Map/Process Inputs to output
    
    
    //Display Your Outputs
     cout<<"A car with a "<<gallon<<" gallon gas tank averages "<<mpgTown
        <<" miles per gallon in town, while it gets on average "<<mpgHigh
        <<" miles per gallon on the highway."<<endl;
     cout<<"The car (on a full tank of gas) will travel "<<mileTwn
         <<" miles in town. On the highway, the car will travel "<<mileHgh
         <<" miles."<<endl;    
    //Exit Program
    return 0;
}

