
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float ttlAcre,
          acre, 
          landL,
          landW,
          landTrt;  
    //Initialize Variables
    acre = 43450;
    landL = 869;
    landW = 360;
    
    
    //Map/Process Inputs to output
     landTrt = landL * landW;
     ttlAcre = landTrt/acre;
     
    //Display Your Outputs
     cout<<"A plot of land that is "<<landL<<" feet long by "<<landW
         <<" feet wide has "<<landTrt
         <<" total feet in size. There are a total of "<<ttlAcre
         <<" acres in this plot of land."<<endl;
           
    //Exit Program
    return 0;
}

