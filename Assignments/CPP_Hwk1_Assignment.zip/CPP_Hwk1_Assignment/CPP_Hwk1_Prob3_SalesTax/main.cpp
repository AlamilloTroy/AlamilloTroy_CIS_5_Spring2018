
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on February 28, 2018 
 * Purpose: Homework Assignment 1 Problem 3 Gladdis 9th Edition.
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl



using namespace std;// namespace where I/O stream was created
const char PERCENT = 100; //Percentage 
const float STATETAX = 6.5; //State Tax Percentage
const float CNTYTAX = 2.0; //County Tax Percentage

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float purSTax, //State tax based on purchase
          purCTax, //County tax based on purchase
          purch, //Original purchase price
          total; //Total payment in $'s 
    
    //Initialize Variables
    purch = 95;
    purSTax = purch*(STATETAX/PERCENT);
    purCTax = purch*(CNTYTAX/PERCENT);
   
    //Map/Process Inputs to output
    total = purch + purSTax + purCTax;
    
    //Display Your Outputs
    cout<<"Your original purchase costs $"<<purch<<"."<<endl;
    cout<<"State tax is $"<<purSTax<<" based on your purchase."<<endl;
    cout<<"County tax is $"<<purCTax<<" based on your purchase."<<endl;
    cout<<"Your total comes out to $"<<total<<"."<<endl;
    
    //Exit Program
    return 0;
}

