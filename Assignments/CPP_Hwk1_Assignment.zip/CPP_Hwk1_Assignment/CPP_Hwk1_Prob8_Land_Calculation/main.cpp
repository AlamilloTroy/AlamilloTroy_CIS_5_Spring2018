
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: Homework Asssignment 1
 
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column
const int ACRE = 43560; //Acre in feet squared
const float SQURMTR = 10.7639; //How many Square feet there is in a Square meter
const int SQFEET = 1; //Square Footage
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float sqmtacr,
          sqftacr,
          halfacr;
    //Initialize Variables
    
    //Map/Process Inputs to output
      halfacr = ACRE/2;
    sqftacr = halfacr*SQFEET;
    sqmtacr = sqftacr/SQURMTR;
    //Display Your Outputs
     cout<<"The Original Area is 1/2 Acres or 0.5 Acres"<<endl;
    cout<<"The total Square Meters there is in half and Acre is: "
            <<sqmtacr<<"m^2"<<endl;
    cout<<"The total Square Feet there is in half an Acre is: "
            << sqftacr<<" sqft"<<endl;
    //Exit Program
    return 0;
}

