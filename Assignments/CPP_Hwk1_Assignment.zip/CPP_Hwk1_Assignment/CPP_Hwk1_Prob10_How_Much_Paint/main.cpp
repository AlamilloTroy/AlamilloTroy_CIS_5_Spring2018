/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 * Created on March 4, 2018
 * Purpose:  Homework Assignment 1 Problem 10
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float pntCov,//Paint Coverage in ft^2/gallon
            fncLnth,//Fence length in feet
            fncHt,  //Fence Hight in feet
            totArea,//Total Area in ft^2
            numGals;//number of gallons of paint
    
    //Initialize Variables
    pntCov=340.0f;
    fncHt=6.0f;
    fncLnth=100.0f;
    
    //Process/Map inputs to outputs
    totArea=4*fncHt*fncLnth;//Both sides painted twice;
    numGals=ceil(totArea/pntCov);
    
    //Output data
    cout<<"Paint coverage per gallon ="<<pntCov<<" ft"<<endl;
    cout<<"Fence Height = "<<fncHt<<" ft"<<endl;
    cout<<"Fence Length = "<<fncLnth<<" ft"<<endl;
    cout<<"Total Area to Cover = "<<totArea<<" ft^2"<<endl;
    cout<<"Number of Gallons of Paint required = "<<numGals<<endl;
    
    //Exit stage right!
    return 0;
}