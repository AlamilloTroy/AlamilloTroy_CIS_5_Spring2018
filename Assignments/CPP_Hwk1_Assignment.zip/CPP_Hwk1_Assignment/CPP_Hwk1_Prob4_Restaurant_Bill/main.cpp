
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018, 
 * Purpose: Homework Assignment 1 Problem 4 
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created
const char PERCENT = 100; //Percentage
const float TAX = 6.75; //tax percentage
const float TIP = 15; //tip percentage

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
     float restBill, //Restaurant Bill
          total, //Total with tax and tip
          tip, //Tip of meal including tax
          tax; //Tax based on meal price
     
    //Initialize Variables
     restBill = 44.50;
    tax = restBill * (TAX/PERCENT);
    tip = (restBill +tax)*(TIP/PERCENT);
    
    //Map/Process Inputs to output
    total = restBill + tax + tip;
    
    //Display Your Outputs
    cout<<"Price of meal is : $ "<< restBill<<endl;
     cout<<"Tax of meal price (6.75%): $ "<<tax<<endl;
     cout<<"Tip(15%) based on price: $ "<<tip<<endl;
     cout<<"Total bill amount: $"<<total<<endl;
    //Exit Program
    return 0;
}

