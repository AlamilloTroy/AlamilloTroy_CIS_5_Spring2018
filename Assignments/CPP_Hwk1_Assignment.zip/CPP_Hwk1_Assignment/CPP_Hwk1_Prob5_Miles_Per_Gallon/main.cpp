
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: Homework Assignment 1 Problem 5
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float gallon,
          miles,
          mpg;  
    //Initialize Variables
    
    //Map/Process Inputs to output
     
    //Display Your Outputs
    cout<<"This program calculates how many miles to the gallon your car gets."
            <<endl;
    cout<<"How many miles can your car drive with a tank full of gas"<<endl;
    cin>>miles;
    cout<<"How many gallons of gas can your car hold?"<<endl;
    cin>>gallon;
    mpg=miles/gallon;
    
    cout<<"Your car gets "<<mpg<<" miles per gallon"<<endl;
     
    //Exit Program
    return 0;
}

