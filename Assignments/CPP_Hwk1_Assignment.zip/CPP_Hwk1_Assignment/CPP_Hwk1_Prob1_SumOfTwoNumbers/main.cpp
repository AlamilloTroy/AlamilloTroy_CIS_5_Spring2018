
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on February 28, 2018
 * Purpose: Problem number one in chapter 2  Gaddis 9th Edition.
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int total,
        int50,
        int100; 
    //Initialize Variables
    int50 = 50; 
    int100 = 100; 
    //Map/Process Inputs to output
            total=int50+int100;
    //Display Your Outputs
    cout<<"Input the integers 50 and 100 to add them together."<<endl;
    cin>>int50;
    cin>>int100;
    cout<<"Total = "<<total<<endl;
    //Exit Program
    return 0;
}

