
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Template
 *          To be copied for each project
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column
const char penny =1;
const char nickel=5;
const char dime =10;
const char quarter=25;
const char dollar=100;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int penn,
        nick,
        dim,
        quart,
        pntot,
        nicktot,
        dimtot,
        quartot,
        totCoin;    
    
    //Initialize Variables
    
    //Map/Process Inputs to output
    cout<<"Enter the number of coins in the order of pennies,"
        <<" nickels, dimes, and quarters to add up to a dollar."<<endl;
    cin>>penny;
    cin>>nickel;
    cin>>dime;
    cin>>quarter;
            
    //Calculations
    pntot=penny*penn;
    nicktot=nickel*nick;
    dimtot=dime*dim;
    quartot=quarter*quart;
    totCoin=pntot+nicktot+dimtot+quartot;
    //Display Your Outputs
    if (totCoin==100){
        cout<<"Your coins add up to one dollar. Good Job!"<<endl;
    }if (totCoin>100){
        cout<<"Your coins do not add up to one dollar. You suck!"<<endl;
    }if (totCoin<100){
        cout<<"Your coins do not add up to one dollar. "
            <<"Go back to school!"<<endl;
    }
    //Exit Program
    return 0;
}

