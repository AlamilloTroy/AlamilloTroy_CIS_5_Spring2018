
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 22, 2018
 * Purpose: CPP Gaddis 9th Edition Chapter 3 Number 1 Minimum / Maximum
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int num1, //Integer for the first number
        num2, //Integer for the second number
        min,  //The minimum number
        max;  //The maximum number  
    
    //Initialize Variables
   
    
    //Map/Process Inputs to output
    cout<<"This program determines of two whole numbers, "
        << "which one is larger and smaller."<<endl;
    
    cout<<"Input the first whole number."<<endl;
    cin>>num1;
    
    cout<<"Input the second whole number."<<endl;
    cin>>num2;
    
    //Display Your Outputs
       if (num1>num2){
        cout<<"The maximum number is "<<num1<<". "<<endl;
        cout<<"The minimum number is "<<num2<<". "<<endl;
    }else{
        cout<<"The maximum number is "<<num2<<". "<<endl;
        cout<<"The minimum number is "<<num1<<". "<<endl;
    }
    //Exit Program
    return 0;
}

