
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 22, 2018
 * Purpose: CPP Gaddis 9thEd Homework Assignment Chapter 3 Problem 3
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int day,  // 30 days in a month
        month,//12 months in a year
        year; //Year   
    //Initialize Variables
    
    //Map/Process Inputs to output
    cout<<"Date format is MM/DD/YY"<<endl;
    cout<<"Input a number for the month, day "
        <<"and two numbers for the year"<<endl;
    cin>>day>>month>>year;
    
    //Display Your Outputs
    cout<<month<<"/"<<day<<"/"<<year<<endl;
    if (month*day==year){
        cout<<"This is a magic date!"<<endl;
    }else{
        cout<<"This is not a magic date."<<endl;
    }
    //Exit Program
    return 0;
}

