
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 2, 2018
 * Purpose: CPP Gaddis Homework Assignment 3 Problem 4
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int length1,
        width1,
        length2,
        width2,
        area1,
        area2;    
    //Initialize Variables
    
    
    
    
    //Map/Process Inputs to output
    cout<<"This program calculates the area of two rectangles"
        <<" and compares them to each other."<<endl;
    cout<<"Input the length of Rectangle 1."<<endl;
    cin>>length1;
    cout<<"Input the width of Rectangle 1."<<endl;
    cin>>width1;
   
    
    cout<<"Input the length of Rectangle 2."<<endl;
    cin>>length2;
    cout<<"Input the width of Rectangle 2."<<endl;
    cin>>width2;
    
    area1= length1*width1;
    area2= length2*width2;
    
    //Display Your Outputs
    if (area1>area2){
        cout<<"Rectangle 1 has a larger area than rectangle 2."<<endl;
    }else{
        cout<<"Rectangle 2 has a larger area than rectangle 1."<<endl;
    }
    //Exit Program
    return 0;
}

