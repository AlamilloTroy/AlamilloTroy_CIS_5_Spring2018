
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 4, 2018
 * Purpose: CPP Gaddis Homework Assignment 3 Problem 5
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int purch,
        ptsEarn;    
    //Initialize Variables
    
    //Map/Process Inputs to output
    cout<<"This program displays how many Book Club points you earned, "
        <<"depending on how many books you purchased this month."<<endl;
    cout<<"input how many books you purchased this month."<<endl;
    cin>>purch;
    
    if (purch==0){
        ptsEarn=0;
        cout<<"You have earned "<<ptsEarn<<" points this month."<<endl;
    }else if (purch==1){
        ptsEarn=5;
        cout<<"You have earned "<<ptsEarn<<" points this month."<<endl;
    }else if (purch==2){
        ptsEarn=15;
        cout<<"You have earned "<<ptsEarn<<" points this month."<<endl;
    }else if (purch==3){
        ptsEarn=30;
        cout<<"You have earned "<<ptsEarn<<" points this month."<<endl;
    }else if (purch>=4){
        ptsEarn=50;
        cout<<"You have earned "<<ptsEarn<<" points this month."<<endl;
    }
    //Display Your Outputs
     
    //Exit Program
    return 0;
}

