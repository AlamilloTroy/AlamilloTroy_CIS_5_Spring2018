
/* 
 * File:   main.cpp
 * Author: Troy Alamillo
 *
 * Created on March 22, 2018
 * Purpose: CPP Gaddis 9thEd Homework Assignment Chapter 3 Problem 2
 */

// System Libraries
#include <iostream>// I/O Library -> cout, endl

using namespace std;// namespace where I/O stream was created

//User Libraries

//Global Constants

//Math, Physics, Science, Conversions, 2D Array Column

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int num; //The integer that will be entered
    
    //Map/Process Inputs to output
    cout<<"Input an integer from 1 - 10 for its Roman numeral."<<endl;
    cin>>num;
    
    //Calculations
    if (num==1){
        cout<<"The Roman Numeral for 1 is I."<<endl;
    }else if (num==2){
        cout<<"The Roman Numeral for 2 is II."<<endl;
    }else if (num==3){
        cout<<"The Roman Numeral for 3 is III."<<endl;
    }else if (num==4){
        cout<<"The Roman Numeral for 4 is IV."<<endl;
    }else if (num==5){
        cout<<"The Roman Numeral for 5 is V."<<endl;
    }else if (num==6){
        cout<<"The Roman Numeral for 6 is VI."<<endl;
    }else if (num==7){
        cout<<"The Roman Numeral for 7 is VII."<<endl;
    }else if (num==8){
        cout<<"The Roman Numeral for 8 is VIII."<<endl;
    }else if (num==9){
        cout<<"The Roman Numeral for 9 is IX."<<endl;
    }else if (num==10){
        cout<<"The Roman Numeral for 10 is X."<<endl;
    }
    //Exit Program
    return 0;
}

